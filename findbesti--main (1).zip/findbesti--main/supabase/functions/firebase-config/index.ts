const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const raw = (key: string) => (Deno.env.get(key) || "").replace(/^["'\s]+|["'\s,]+$/g, "");

  const authDomain = raw("FIREBASE_AUTH_DOMAIN").replace(/^https?:\/\//, "");

  return new Response(
    JSON.stringify({
      apiKey: raw("FIREBASE_API_KEY"),
      authDomain,
      projectId: raw("FIREBASE_PROJECT_ID"),
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
});
